# Fetal Health Classification

Machine-learning project that classifies the **fetal state (Normal, Suspect, Pathologic)** from cardiotocography (CTG) measurements.

> **Disclaimer:** this is an educational project. It is not a medical device and must not be used for clinical decisions.

## Project overview

Cardiotocography records the fetal heart rate and uterine contractions. This project uses 21 automatically extracted CTG measurements from the public UCI *Cardiotocography* dataset to train and compare seven machine-learning models. The whole workflow (loading, cleaning, exploratory analysis, preprocessing, training, tuning, evaluation, comparison and conclusion) is in one self-contained Jupyter notebook.

**Best result:** Gradient Boosting reached **94.8 % accuracy**, a **macro F1-score of 0.9031** and a one-vs-rest **ROC AUC of 0.9862** on a stratified hold-out test set of 426 recordings.

## Project description

The notebook walks through the complete data-science pipeline:

1. Load and inspect the raw UCI file (2,129 rows, 40 columns).
2. Clean the data: remove 3 empty rows, keep the 21 measurement features and the target, and drop identifier columns and expert-label columns to **prevent data leakage**.
3. Explore the data with class-distribution plots, density plots, box plots and correlation analysis.
4. Split the data (stratified 80 % / 20 %) and scale the features inside scikit-learn pipelines, so nothing leaks from validation or test data.
5. Compare seven models with 5-fold stratified cross-validation, then tune three of them with grid search.
6. Evaluate on the untouched test set with accuracy, macro precision, macro recall, macro F1, ROC AUC, confusion matrices, ROC curves and per-class results.
7. Analyse feature importance (permutation importance and Random Forest importance).

## Problem statement

Given 21 numerical features of a cardiotocogram, predict the fetal state assigned by expert obstetricians (Normal, Suspect or Pathologic). The data is imbalanced (about 78 % Normal) and the Suspect class overlaps with its neighbours, so accuracy alone is not enough and macro-averaged metrics are used.

## Objectives

- Prepare the CTG data without data leakage.
- Understand the data through exploratory analysis and visualisation.
- Train, tune and compare several machine-learning models fairly.
- Evaluate with metrics suited to imbalanced classes.
- Identify the most influential CTG features.
- Provide a reproducible notebook and a written report.

## Dataset information

| Item | Details |
|---|---|
| Name | Cardiotocography (UCI Machine Learning Repository, dataset ID 193) |
| Source / link | https://archive.ics.uci.edu/dataset/193/cardiotocography |
| License | Creative Commons Attribution 4.0 (CC BY 4.0) |
| Records | 2,126 CTG recordings (after removing 3 empty rows from the raw file) |
| Input features | 21 numerical measurements (LB, AC, FM, UC, DL, DS, DP, ASTV, MSTV, ALTV, MLTV, Width, Min, Max, Nmax, Nzeros, Mode, Mean, Median, Variance, Tendency) |
| Target | `NSP`: 1 = Normal (1655), 2 = Suspect (295), 3 = Pathologic (176) |
| File in this repository | `CTG.csv` (the raw UCI data, unchanged) |

The dataset file is **included in this repository** so the notebook runs without any download. Keep `CTG.csv` in the same folder as the notebook. If it is ever missing, download the data from the UCI link above and save it as `CTG.csv`.

**Citation:** Ayres de Campos, D. (2010). *Cardiotocography* [Dataset]. UCI Machine Learning Repository. Original work: Ayres de Campos et al. (2000), *SisPorto 2.0: a program for automated analysis of cardiotocograms*, Journal of Maternal-Fetal Medicine.

## Technologies used

Python 3, Jupyter Notebook, NumPy, pandas, Matplotlib, seaborn, scikit-learn.

## Features

- One self-contained notebook, no helper scripts.
- Leakage-safe preprocessing with scikit-learn pipelines.
- Seven models: Logistic Regression, K-Nearest Neighbours, SVM (RBF), Decision Tree, Random Forest, Histogram Gradient Boosting and a Multi-Layer Perceptron (neural network).
- Cross-validated hyper-parameter tuning (SVM, Random Forest, Gradient Boosting).
- Model selection on training-data cross-validation only; the test set is used once.
- Full evaluation: confusion matrices, ROC curves, per-class metrics, feature importance.
- Fixed random seed (`42`) for reproducible results.

## Methodology

| Step | Description |
|---|---|
| Split | Stratified 80 % train (1700) / 20 % test (426) |
| Preprocessing | `StandardScaler` inside a `Pipeline` (fitted on training data only) |
| Class imbalance | `class_weight="balanced"` for models that support it |
| Cross-validation | 5-fold stratified, scored with macro-F1 |
| Tuning | `GridSearchCV` for SVM, Random Forest and Gradient Boosting |
| Main metric | Macro-averaged F1-score (plus accuracy, precision, recall, ROC AUC) |

## Installation / setup

Requirements: Python 3.10 or newer (tested with Python 3.12).

```bash
# 1. get the repository
git clone https://github.com/<your-username>/Fetal-Health-Classification.git
cd Fetal-Health-Classification

# 2. (optional) create a virtual environment
python -m venv .venv
# Windows:  .venv\Scripts\activate
# macOS/Linux:  source .venv/bin/activate

# 3. install the libraries
pip install -r requirements.txt
```

(Instead of cloning you can also download the repository as a ZIP file from GitHub and unzip it.)

## How to run

```bash
jupyter notebook Priya_FetalHealthClassification.ipynb
```

Then choose **Kernel -> Restart & Run All** (or *Run -> Run All Cells*). The full run takes a few minutes, mainly because of the hyper-parameter search. The notebook prints all tables and shows all plots; it does not write any files unless you set `SAVE_FIGURES = True` in the first code cell.

## Repository structure

```text
Fetal-Health-Classification/
|
|-- Priya_FetalHealthClassification.ipynb   # complete notebook (code, outputs, conclusion)
|-- requirements.txt                        # Python libraries
|-- README.md                               # this file
|-- Priya_FetalHealthProjectReport.docx     # full project report
|-- CTG.csv                                 # dataset (UCI Cardiotocography, CC BY 4.0)
```

## Results

Test-set results (hold-out set of 426 recordings, sorted by macro-F1):

| Model | Accuracy | Precision (macro) | Recall (macro) | F1 (macro) | ROC AUC (OvR) |
|---|---|---|---|---|---|
| Gradient Boosting | 0.9484 | 0.9054 | 0.9012 | 0.9031 | 0.9862 |
| Random Forest | 0.9390 | 0.8955 | 0.8879 | 0.8913 | 0.9819 |
| SVM (RBF) | 0.9131 | 0.8345 | 0.8506 | 0.8423 | 0.9753 |
| Decision Tree | 0.8638 | 0.7826 | 0.8666 | 0.8099 | 0.9198 |
| Neural Network (MLP) | 0.8967 | 0.8191 | 0.7522 | 0.7802 | 0.9618 |
| Logistic Regression | 0.8615 | 0.7397 | 0.8347 | 0.7741 | 0.9579 |
| K-Nearest Neighbours | 0.8826 | 0.8177 | 0.7214 | 0.7619 | 0.9406 |

Cross-validated macro-F1 on the training data of the three tuned models: Gradient Boosting 0.9264, Random Forest 0.9012, SVM 0.8699.

## Key information

- **Best model:** Gradient Boosting, chosen by cross-validation on the training data (not by test score). Random Forest was a close second.
- **Hardest class:** Suspect, which had the lowest per-class F1-score for every model.
- **Most influential features:** `ASTV` and `ALTV` (percentage of time with abnormal short- and long-term variability), followed by `AC` (accelerations) and the histogram mean.
- **Caution:** the test set contains only 35 Pathologic and 59 Suspect recordings, so per-class numbers are uncertain; the ranking of the top models is more reliable than the exact decimals.
- **Reproducibility:** results were reproduced in a fresh virtual environment built from `requirements.txt`. Small numerical differences are possible with other library versions.

## Author

**Priya**

## Acknowledgements

- Dataset: UCI Machine Learning Repository, *Cardiotocography* (CC BY 4.0).
- The general idea of classifying this dataset was explored in a public reference project (https://github.com/evercloud/machine-and-deep-learning-project). The code, experiments, results and report in this repository were produced independently.
